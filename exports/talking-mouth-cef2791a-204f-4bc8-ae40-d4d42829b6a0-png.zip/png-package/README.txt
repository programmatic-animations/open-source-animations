PLAYBACK RATE: 30 fps. 222 frames = 7.400 seconds.

PNG sequences do not carry a playback frame rate. At 24 fps this sequence lasts 9.250 seconds (25% too long).

DaVinci Resolve: Extract this ZIP. In Media page > Media Storage, disable Show Individual Frames. Import frame-[00000-...].png as one image sequence. In the Media Pool, right-click the sequence > Clip Attributes > Video Frame Rate: 30; Alpha Mode: Straight. Do this before adding it to the timeline. Set the SOURCE clip rate to 30 even if your timeline uses another rate. Place above your main video. Import voice.wav separately if included, aligned to the first frame. Frames are 512x512 RGBA PNGs.